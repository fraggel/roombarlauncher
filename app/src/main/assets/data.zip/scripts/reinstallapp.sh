#!/system/bin/sh

## application configuration
pkill es.tfandroid.roombarlauncher
pm install -r /sdcard/droidphp/roombarlauncher.apk
am start -n es.tfandroid.roombarlauncher/es.tfandroid.roombarlauncher.InicioActivity
